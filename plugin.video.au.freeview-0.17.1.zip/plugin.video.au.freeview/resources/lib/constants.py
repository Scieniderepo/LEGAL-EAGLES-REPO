REGIONS  = ['Sydney', 'Melbourne', 'Brisbane', 'Perth', 'Adelaide', 'Darwin', 'Hobart', 'Canberra']
M3U8_URL = 'https://i.mjh.nz/au/{region}/tv.json.gz'
EPG_URL  = 'https://i.mjh.nz/au/{region}/epg.xml.gz'