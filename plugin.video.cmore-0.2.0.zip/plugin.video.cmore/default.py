# -*- coding: utf-8 -*-
import addon

if __name__ == '__main__':
    addon.run()
