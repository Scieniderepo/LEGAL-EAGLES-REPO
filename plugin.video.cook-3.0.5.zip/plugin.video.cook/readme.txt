plugin.video.cook
================

Kodi Addon for Cooking Channel website

v3.0.5 website change
V3.0.3 minor website change
V3.0.2 website changes rip out cache
V3.0.1 separate scraper for future functions
V2.0.1 Initial version