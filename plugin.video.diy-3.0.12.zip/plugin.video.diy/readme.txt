plugin.video.diy
================

Kodi Addon for DIY Network website

v3.0.12 website change
v3.0.11 website change
V3.0.10 use ignorecase for regex
V3.0.9 minor website change
V3.0.8 minor website change
V3.0.7 website change
V3.0.6 website change
V3.0.5 website changes
V3.0.4 website changes
V3.0.2 website changes
V3.0.1 Separate scraper for future functions
V2.0.1 Initial version