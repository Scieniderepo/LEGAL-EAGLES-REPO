# plugin.video.dplay
Kodi unofficial plugin for Dplay.
