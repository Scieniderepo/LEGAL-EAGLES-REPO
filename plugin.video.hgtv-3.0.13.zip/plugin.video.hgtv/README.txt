plugin.video.hgtv
================

Kodi Addon for HGTV website

icon.png sourced from public domain : 
https://commons.wikimedia.org/wiki/File:HGTV_Logo.svg

fanart.jpg sourced from public domain:
https://commons.wikimedia.org/wiki/File:HGTV_Logo.svg (converted to .jpg)

Version 3.0.13 website change
Version 3.0.12 use ignorecase for regex
Version 3.0.11 minor website change
Version 3.0.10 minor website change
Version 3.0.9 website change
Version 3.0.8 website change
Version 3.0.7 website change
Version 3.0.6 website change, cleanup
Version 3.0.5 bumped t1mlib version for cacheToDisc problem
Version 3.0.4 website changes
Version 3.0.3 website changes
Version 3.0.2 website changes
Version 3.0.1 Isengard - separate scraper

Version 2.1.5 fix for null url from website
Version 2.1.4 Website changes
Version 2.1.3 Fix for finding first show
Version 2.1.2 Added subtitles, metadata, fixed views
Version 2.1.1 Cleanup and fix spaces after name
Version 2.1.0 Website changes
version 2.0.2 initial release

