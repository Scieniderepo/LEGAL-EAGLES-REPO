plugin.video.hgtv.canada
================

Kodi Addon for HGTV Canada website

Version 3.0.3 fix for playable url - thanks to forum user: hgtv
Version 3.0.2 website changes
Version 3.0.1 Isengard - separate scraper
