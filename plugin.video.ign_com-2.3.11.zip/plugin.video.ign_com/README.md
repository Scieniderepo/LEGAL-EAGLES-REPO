Video Plugin for IGN.com

Game and Movie trailers/reviews/news.
Original work by Twister and AddonScriptorDE.
