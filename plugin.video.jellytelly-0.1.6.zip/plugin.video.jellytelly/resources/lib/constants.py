HEADERS = {'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 8.1.0; MI 5 Build/OPM7.181205.001)'}

API_URL = 'https://api.gominno.com{}'