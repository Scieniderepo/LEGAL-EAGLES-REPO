plugin.video.metv
================

Kodi Addon for MeTV website

Version 3.0.8 website changes
Version 3.0.4 website change
Version 3.0.3 website changes
Version 3.0.1 separate scraper for future functions
Version 2.0.2 cleanup for release and website change
version 2.0.1 initial release

