MLB Basesloaded is the MLB.tv Redzone for Kodi.

Please add an Issue on [GitHub](https://github.com/jakecar/plugin.video.mlbbasesloaded) if you find a bug. Pull requests are always welcomed.

# Credits
* Dan Brooks for his original MLB.tv Redzone: http://www.brooksbaseball.net/hilev/redzone.php
* Tom Tango for his Leverage Index table: http://www.insidethebook.com/li.shtml
* eracknaphobia for his Kodi MLB.tv app: https://github.com/eracknaphobia/plugin.video.mlbtv
