class StreamNotFoundException(Exception): pass

class SignOnRestrictionException(Exception): pass