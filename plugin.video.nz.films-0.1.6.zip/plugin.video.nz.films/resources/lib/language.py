from slyguy.language import BaseLanguage

class Language(BaseLanguage):
    ASK_USERNAME = 30001
    ASK_PASSWORD = 30002
    MY_LIBRARY   = 30003

_ = Language()