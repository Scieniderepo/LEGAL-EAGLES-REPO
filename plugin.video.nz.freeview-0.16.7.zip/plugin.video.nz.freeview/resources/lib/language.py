from slyguy.language import BaseLanguage

class Language(BaseLanguage):
    LIVE_TV       = 30000

_ = Language()