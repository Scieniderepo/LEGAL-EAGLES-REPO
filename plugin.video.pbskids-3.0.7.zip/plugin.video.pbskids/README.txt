plugin.video.pbskids
================

Kodi Addon for Think TV PBS Kids Video website

Version 3.0.7 API changes
Version 3.0.5 website changes
Version 3.0.4 unicode fix
Version 3.0.3 fixed metadata issues
Version 3.0.2 fixed metadata issues
Version 3.0.1 Separate scraper for future functions
