# Rocketbeans TV plugin for Kodi
This is a rewrite based upon the work of Jin and Ulukai.
You can find that original version here https://github.com/LeUlukai/plugin.video.rocketbeanstvlive

## Make sure to enable MPEG-DASH in your YouTube addon