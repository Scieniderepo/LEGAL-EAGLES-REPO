# Steam Community plugin for Kodi

Steam Community a KODI (XBMC) plugin for Steamcommunity.com.

Git repo: https://github.com/MrKrabat/plugin.video.steamcommunity

Forum posting: xxx
***

What this plugin currently can do:
- [x] Filter for language
- [x] Filter for popular or new
- [x] Search for game hubs
- [x] View screenshots, artworks, videos and broadcasts

Broadcasts require Inputstream.Adaptive v2.2.19 or newer.
***

_This website and addon is not affiliated with Valve Corporation or Steam._

_Kodi® (formerly known as XBMC™) is a registered trademark of the XBMC Foundation.
This website and addon is not affiliated with Kodi, Team Kodi, or the XBMC Foundation._