plugin.video.sundance
================

Kodi Addon for The Sundance TV Video website

Version 3.0.1 Separate scraper for future functions
Version 2.0.1 Isengard Version website fixes

Version 1.0.1 initial release
Version 1.0.2 website change
Version 1.0.3 website change