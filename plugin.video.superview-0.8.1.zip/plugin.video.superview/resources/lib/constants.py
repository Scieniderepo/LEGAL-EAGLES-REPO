HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.190 Safari/537.36',
}

BASE_URL = 'https://www.supercars.com/'
PASSWORD_KEY = 'QXff'

BRIGHTCOVE_URL = 'https://edge.api.brightcove.com/playback/v1/accounts/{}/videos/{}'
BRIGHTCOVE_KEY = 'BCpkADawqM0_4J6Oa-Vp-_S7CiP77ylYCzC-dEFbNdY_psjSngN9mdH2QF25U80yc82LceQE7KmbGIUHCQHHeItznokQVdDTQ0Mn-87Sc6nBA3gEHFhE29bHe45NIUkW5j7IPakRZnyh-KFJQ7wAggSr63oL6YSK_IA2jmoEyjCuJ4z329ISfycWnrHgBXzpOXuNkMrLQdOQILq83GYBvJZXl7H1xX77cyelvMbgPEfCu0MndCiGa8KIhLOCxWmg6EgB_zAirE-oPpLEqBXkst7nUNllm8jICVgMUtoX7grfyATatyySmZfL5tzUSqo0R1cfOydFZHckziPyaI_uz_7tlurME8jrgpVl7b5nH8sQI3AmvncSYoF9MQsdAsC8JsWSnYcrjJwt7LEYoHhDcX1ccxtAbUIAz9dU1btaS56YuRVMKCcJFVvo1ymmPYjJkqgYCMVEcm-IQe6fU703SrNnlnrta9egLe8ccZiKzDrucCRk84sf0w8EkUc'

RACES_CACHE_TIME = (60*5)