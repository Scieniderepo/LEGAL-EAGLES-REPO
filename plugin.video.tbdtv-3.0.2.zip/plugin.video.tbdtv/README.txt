plugin.video.tbdtv
================

Kodi Video Addon for TBD TV Live
For Kodi Krypton and above releases

Version 3.0.1 initial release

