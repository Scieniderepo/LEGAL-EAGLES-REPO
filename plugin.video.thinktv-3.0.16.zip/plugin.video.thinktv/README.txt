plugin.video.thinktv
================

Kodi Video Addon for PBS ThinkTV
For Kodi Krypton and above releases

version 3.0.16 fixes for website changes
version 3.0.15 fixes for displaying episodes - thanks to Brian Murrell
version 3.0.14 fix getvideo for new api
version 3.0.13 fix movies/specials to be able to play
version 3.0.12 try to handle multiple seasons
version 3.0.11 website change, use inputstream.adaptive to speed stream selection, needs Krypton or above
version 3.0.10 quick fix for website change
version 3.0.9 fix for website change, add episode search
version 3.0.8 fix for website change
version 3.0.7 fix for episode, clip and preview counts
version 3.0.6 fix for API bug when station is empty
Version 3.0.5 fix for Passport / user id
Version 3.0.4 fix for 1080, ecnt bug
Version 3.0.3 cleanup
Version 3.0.1 separate scraper for future functions

