plugin.video.viewster================

Kodi Addon for Viewster website

Version 2.0.3 fix for non-English videos
Version 2.0.2 website change
Version 2.0.1 Rewrite for new API, added views

Version 1.0.6 category encoding fix, thanks to Andre Koehler
Version 1.0.5 feed change - m3u8 support
Version 1.0.4 added "all languages" support
Version 1.0.3 added language support
version 1.0.2 added higher res video support
version 1.0.1 initial release

