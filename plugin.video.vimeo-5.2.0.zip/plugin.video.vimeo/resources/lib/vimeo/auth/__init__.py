#! /usr/bin/env python
# encoding: utf-8

from __future__ import absolute_import


class GrantFailed(Exception):
    """Grant permission failed."""

    pass
