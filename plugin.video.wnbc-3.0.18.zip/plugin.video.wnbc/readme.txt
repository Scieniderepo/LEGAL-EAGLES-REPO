Version 3.0.18 website change
Version 3.0.17 website change
Version 3.0.16 fix for multiple page shows
Version 3.0.15 website change
Version 3.0.14 website change
Version 3.0.12 website change
Version 3.0.11 changes for Android Kodi 17
Version 3.0.10 website change
Version 3.0.9 website change
Version 3.0.8 bump version for t1mlib for request timeout fix in Kodi 17.0 android
Version 3.0.7 Bug fix for TV Shows with ':' in title
Version 3.0.6 Bug fix for no fanart image
Version 3.0.5 Added 'Add to Library'
Version 3.0.4 bumped t1mlib version, fix SNL
Version 3.0.2 Isengard version