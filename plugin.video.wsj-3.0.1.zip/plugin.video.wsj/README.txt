plugin.video.wsj
================

Version 3.0.1 Krypton release
