import sys
from resources.lib import plugin

plugin.run(sys.argv)