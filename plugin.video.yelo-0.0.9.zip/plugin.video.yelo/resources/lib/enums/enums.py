class protocols:
    HLS = "HLS"
    DASH = "DASH"
    HSS = "HSS"
