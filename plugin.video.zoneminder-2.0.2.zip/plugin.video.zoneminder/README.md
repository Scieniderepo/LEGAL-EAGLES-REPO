plugin.video.zoneminder
=======================

- ZoneMinder plugin for Kodi 17+
- View live stream of cameras
- Requires Zoneminder API 1.32+
- Supports username/password authentication
